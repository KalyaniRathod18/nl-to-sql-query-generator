# init_db.py
import sqlite3

conn = sqlite3.connect('sample.db')
c = conn.cursor()

c.execute('DROP TABLE IF EXISTS employees;')
c.execute('''
CREATE TABLE employees (
    id INTEGER PRIMARY KEY,
    name TEXT,
    department TEXT,
    salary INTEGER,
    hire_date TEXT,
    city TEXT
)
''')

rows = [
    (1, 'Alice', 'Engineering', 85000, '2019-03-15', 'Bengaluru'),
    (2, 'Bob', 'Sales', 55000, '2020-07-01', 'Mumbai'),
    (3, 'Carol', 'HR', 60000, '2018-10-20', 'Chennai'),
    (4, 'Dan', 'Engineering', 95000, '2017-01-05', 'Bengaluru'),
    (5, 'Eve', 'Sales', 72000, '2021-05-30', 'Delhi'),
    (6, 'Frank', 'Support', 48000, '2022-02-14', 'Kolkata'),
    (7, 'Grace', 'Engineering', 79000, '2016-08-09', 'Mumbai'),
    (8, 'Heidi', 'HR', 61000, '2015-12-01', 'Chennai'),
]

c.executemany('INSERT INTO employees VALUES (?,?,?,?,?,?)', rows)
conn.commit()
conn.close()

print("sample.db created and populated.")
