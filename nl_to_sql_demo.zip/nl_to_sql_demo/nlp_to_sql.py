# nlp_to_sql.py
import re

# map English words to actual column names
COL_MAP = {
    'id': 'id',
    'name': 'name',
    'employee name': 'name',
    'department': 'department',
    'dept': 'department',
    'salary': 'salary',
    'pay': 'salary',
    'hire date': 'hire_date',
    'hired': 'hire_date',
    'hire_date': 'hire_date',
    'city': 'city',
    'location': 'city',
}

# known table hints
TABLE_KEYWORDS = {
    'employees': ['employee', 'employees', 'staff', 'workers', 'people'],
    # future: add more tables like 'sales': ['sale','sales','orders']
}

def escape_sql(val: str) -> str:
    return val.replace("'", "''")

def nl_to_sql(text: str) -> str:
    """Convert a short English query to a simple SQL SELECT (demo-level)."""
    if not text or not text.strip():
        return "SELECT * FROM employees;"

    t = text.lower()

    # choose table (default employees)
    table = 'employees'
    for tbl, keys in TABLE_KEYWORDS.items():
        for k in keys:
            if k in t:
                table = tbl
                break

    # SELECT columns
    select_clause = '*'
    cols = []
    m = re.search(r'(?:show|list|get|find|display|give me)\s+(.*?)(?:\s+from|\s+where|\s+who|\s+with|$)', t)
    if m:
        part = m.group(1)
        tokens = re.split(r',| and | & ', part)
        for tok in tokens:
            tok = tok.strip()
            if not tok:
                continue
            for k in COL_MAP:
                if k in tok:
                    cols.append(COL_MAP[k])
                    break

    if 'all' in t or 'everything' in t:
        select_clause = '*'
    elif cols:
        # dedupe while preserving order
        select_clause = ', '.join(dict.fromkeys(cols))
    else:
        # fallback: if any column word appears pick that column (very simple)
        for k, v in COL_MAP.items():
            if k in t:
                select_clause = v
                break

    # WHERE clauses (basic numeric and text equality detection)
    where_clauses = []

    # numeric comparators in phrase form
    comp_map = {
        'greater than or equal to': '>=',
        'greater than or equal': '>=',
        'greater than': '>',
        'more than': '>',
        'less than or equal to': '<=',
        'less than or equal': '<=',
        'less than': '<',
        'fewer than': '<',
        'equal to': '=',
        'equals': '=',
        'not equal': '!=',
    }

    for phrase, op in comp_map.items():
        pattern = rf'([a-z_ ]+?)\s+{re.escape(phrase)}\s+(\d+)'
        for match in re.finditer(pattern, t):
            col_raw = match.group(1).strip()
            val = match.group(2)
            col_name = None
            for k in COL_MAP:
                if k in col_raw:
                    col_name = COL_MAP[k]
                    break
            if not col_name:
                col_name = col_raw.replace(' ', '_')
            where_clauses.append(f"{col_name} {op} {val}")

    # textual equality (department is Sales, city Mumbai, name Alice)
    for field in ['department', 'dept', 'city', 'name']:
        m = re.search(rf'{field}\s*(?:is|=|in|of|for)?\s*([a-z0-9 ]+)', t)
        if m:
            val = m.group(1).strip()
            # ignore stray words like 'show' etc
            if val and val not in ['show', 'list', 'get', 'find', 'top', 'first', 'all']:
                val = escape_sql(val)
                col = COL_MAP.get(field, field)
                where_clauses.append(f"{col} = '{val}'")

    # special phrasing: "in the sales department"
    m = re.search(r'in (?:the )?([a-z0-9 ]+?) department', t)
    if m:
        val = escape_sql(m.group(1).strip())
        where_clauses.append(f"department = '{val}'")

    # ORDER BY detection
    order_clause = ''
    m = re.search(r'(order by|sorted by)\s+([a-z_]+)(?:\s+(ascending|descending|asc|desc))?', t)
    if m:
        col = m.group(2)
        for k in COL_MAP:
            if k in col:
                col = COL_MAP[k]
                break
        dir = 'ASC'
        if m.group(3) and m.group(3).startswith('desc'):
            dir = 'DESC'
        order_clause = f"ORDER BY {col} {dir}"
    else:
        m = re.search(r'(highest|lowest|biggest|smallest)\s+([a-z_]+)', t)
        if m:
            dir_word = m.group(1)
            col = m.group(2)
            for k in COL_MAP:
                if k in col:
                    col = COL_MAP[k]
                    break
            order_clause = f"ORDER BY {col} {'DESC' if dir_word in ['highest','biggest'] else 'ASC'}"

    # LIMIT detection
    limit_clause = ''
    m = re.search(r'(?:top|first|show)\s+(\d+)', t)
    if m:
        limit_clause = f"LIMIT {m.group(1)}"
    else:
        m = re.search(r'limit\s+(\d+)', t)
        if m:
            limit_clause = f"LIMIT {m.group(1)}"

    # build SQL
    sql = f"SELECT {select_clause} FROM {table}"
    if where_clauses:
        sql += " WHERE " + " AND ".join(where_clauses)
    if order_clause:
        sql += " " + order_clause
    if limit_clause:
        sql += " " + limit_clause
    sql += ";"
    return sql
