# app.py
from flask import Flask, render_template, request, g
import sqlite3
from nlp_to_sql import nl_to_sql

DATABASE = 'sample.db'
app = Flask(__name__)

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

@app.route('/', methods=['GET', 'POST'])
def index():
    sql = ''
    rows = []
    error = None
    if request.method == 'POST':
        nl = request.form.get('nl_query', '')
        try:
            sql = nl_to_sql(nl)
            cur = get_db().execute(sql)
            rows = cur.fetchall()
            cur.close()
        except Exception as e:
            error = str(e)
    return render_template('index.html', sql=sql, rows=rows, error=error)

if __name__ == '__main__':
    app.run(debug=True)
